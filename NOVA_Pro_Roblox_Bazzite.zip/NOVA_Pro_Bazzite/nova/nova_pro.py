#!/usr/bin/env python3
"""NOVA Pro — a polished, local-first Roblox/Sober launcher for Bazzite."""
import json, os, shutil, subprocess, threading, time, webbrowser, platform, re
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

APP_NAME = "NOVA Pro"
SOBER_ID = "org.vinegarhq.Sober"
ROOT = Path.home() / ".local" / "share" / "nova-pro"
DATA = ROOT / "settings.json"
LOG = ROOT / "nova.log"
SOBER_CONFIG = Path.home() / ".var/app/org.vinegarhq.Sober/config/sober/config.json"
ROOT.mkdir(parents=True, exist_ok=True)

C = {
    "bg":"#090b12", "sidebar":"#0d111b", "panel":"#121827", "panel2":"#182136",
    "panel3":"#202b43", "line":"#263149", "text":"#f2f5ff", "muted":"#8996b1",
    "purple":"#9b7bff", "purple2":"#7657e8", "cyan":"#55d6e8", "green":"#5ce1a0",
    "yellow":"#f7c66b", "red":"#ff7188"
}
DEFAULTS = {
    "profile":"Balanced", "graphics_optimization_mode":"balanced",
    "enable_gamemode":True, "use_opengl":False, "enable_hidpi":False,
    "discord_rpc_enabled":False, "server_location_indicator_enabled":False,
    "enable_mobile_home_screen":False, "allow_gamepad_permission":False,
    "discord_rpc_show_join_button":False, "use_libsecret":False,
    "touch_mode":"off", "close_on_leave":True, "use_console_experience":False,
    "launch_arguments":"", "launch_mode":"sober", "theme":"Midnight Violet",
    "show_system_stats":True, "auto_refresh_stats":True, "last_place_url":""
}

def command(args, timeout=5):
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    except Exception:
        return None

def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}

def write_log(msg):
    try:
        with LOG.open("a", encoding="utf-8") as f:
            f.write(time.strftime("[%Y-%m-%d %H:%M:%S] ") + str(msg) + "\n")
    except Exception:
        pass

def load_settings():
    d = dict(DEFAULTS)
    d.update(read_json(DATA))
    return d

def save_sober_config(changes):
    SOBER_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    current = read_json(SOBER_CONFIG)
    if SOBER_CONFIG.exists():
        try:
            shutil.copy2(SOBER_CONFIG, SOBER_CONFIG.with_name("config.json.nova-backup"))
        except Exception:
            pass
    current.update(changes)
    temp = SOBER_CONFIG.with_suffix(".json.tmp")
    temp.write_text(json.dumps(current, indent=2) + "\n", encoding="utf-8")
    temp.replace(SOBER_CONFIG)

def has_flatpak():
    p = command(["flatpak", "info", SOBER_ID])
    return bool(p and p.returncode == 0)

def sys_stats():
    # Read-only best-effort stats; no extra packages needed.
    cpu = "—"
    ram = "—"
    gpu = "—"
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemTotal:"): total = int(line.split()[1])
            elif line.startswith("MemAvailable:"): avail = int(line.split()[1])
        ram = f"{(total-avail)/1024:.0f} / {total/1024:.0f} MB"
    except Exception:
        pass
    try:
        loads = os.getloadavg()
        cpu = f"{loads[0]:.2f} load"
    except Exception:
        pass
    try:
        p = command(["sh","-lc","for f in /sys/class/drm/card*/device/uevent; do grep -h '^DRIVER=' \"$f\"; done"])
        if p and p.stdout.strip():
            gpu = ", ".join(sorted(set(x.split("=",1)[1] for x in p.stdout.splitlines() if "=" in x)))
    except Exception:
        pass
    return cpu, ram, gpu

class Nova:
    def __init__(self, root):
        self.root = root
        self.settings = load_settings()
        self.page = "Dashboard"
        self.vars = {}
        self.nav_buttons = {}
        self.root.title("NOVA Pro — Roblox on Linux")
        self.root.geometry("1120x760")
        self.root.minsize(950, 660)
        self.root.configure(bg=C["bg"])
        self.style()
        self.layout()
        self.show_page("Dashboard")
        self.refresh_status()
        self.refresh_stats()

    def style(self):
        s = ttk.Style()
        try: s.theme_use("clam")
        except Exception: pass
        s.configure("Nova.TCombobox", fieldbackground=C["panel2"], background=C["panel2"], foreground=C["text"], arrowcolor=C["purple"], bordercolor=C["line"])
        s.map("Nova.TCombobox", fieldbackground=[("readonly", C["panel2"])], foreground=[("readonly", C["text"])])
        s.configure("Nova.Horizontal.TProgressbar", troughcolor=C["panel2"], background=C["purple"], bordercolor=C["panel2"], lightcolor=C["purple"], darkcolor=C["purple"])

    def button(self, parent, text, cmd, primary=False, compact=False):
        return tk.Button(parent, text=text, command=cmd, bg=C["purple2"] if primary else C["panel2"],
            fg=C["text"], activebackground=C["purple"] if primary else C["panel3"], activeforeground="white",
            relief="flat", bd=0, padx=13 if compact else 17, pady=8 if compact else 12,
            cursor="hand2", font=("DejaVu Sans", 9, "bold"), highlightthickness=0)

    def card(self, parent, title=None, subtitle=None):
        f = tk.Frame(parent, bg=C["panel"], highlightbackground=C["line"], highlightthickness=1)
        if title:
            tk.Label(f, text=title, bg=C["panel"], fg=C["text"], font=("DejaVu Sans", 12, "bold")).pack(anchor="w", padx=16, pady=(14,2))
        if subtitle:
            tk.Label(f, text=subtitle, bg=C["panel"], fg=C["muted"], font=("DejaVu Sans", 9)).pack(anchor="w", padx=16, pady=(0,10))
        return f

    def layout(self):
        self.sidebar = tk.Frame(self.root, bg=C["sidebar"], width=220)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        brand = tk.Frame(self.sidebar, bg=C["sidebar"])
        brand.pack(fill="x", padx=20, pady=(24,28))
        mark = tk.Label(brand, text="N", bg=C["purple2"], fg="white", font=("DejaVu Sans", 19, "bold"), width=2, height=1)
        mark.pack(side="left")
        info = tk.Frame(brand, bg=C["sidebar"])
        info.pack(side="left", padx=10)
        tk.Label(info, text="NOVA", bg=C["sidebar"], fg=C["text"], font=("DejaVu Sans", 17, "bold")).pack(anchor="w")
        tk.Label(info, text="PRO • BAZZITE", bg=C["sidebar"], fg=C["purple"], font=("DejaVu Sans", 8, "bold")).pack(anchor="w")
        tk.Label(self.sidebar, text="WORKSPACE", bg=C["sidebar"], fg=C["muted"], font=("DejaVu Sans", 8, "bold")).pack(anchor="w", padx=20, pady=(0,9))
        for name, icon in [("Dashboard","⌂"),("Settings","⚙"),("Performance","◈"),("Profiles","▦"),("Tools","✣"),("About","ⓘ")]:
            b = tk.Button(self.sidebar, text=f"  {icon}   {name}", anchor="w", command=lambda n=name:self.show_page(n),
                bg=C["sidebar"], fg=C["muted"], activebackground=C["panel2"], activeforeground=C["text"],
                relief="flat", bd=0, padx=14, pady=11, font=("DejaVu Sans", 10, "bold"), cursor="hand2")
            b.pack(fill="x", padx=10, pady=2)
            self.nav_buttons[name] = b
        spacer = tk.Frame(self.sidebar, bg=C["sidebar"])
        spacer.pack(fill="both", expand=True)
        self.sidebar_status = tk.Label(self.sidebar, text="● Checking Sober…", bg=C["sidebar"], fg=C["yellow"], font=("DejaVu Sans", 9, "bold"))
        self.sidebar_status.pack(anchor="w", padx=20, pady=(0,6))
        tk.Label(self.sidebar, text="Local-first • No account data", bg=C["sidebar"], fg=C["muted"], font=("DejaVu Sans", 8)).pack(anchor="w", padx=20, pady=(0,20))

        self.main = tk.Frame(self.root, bg=C["bg"])
        self.main.pack(side="left", fill="both", expand=True)
        self.topbar = tk.Frame(self.main, bg=C["bg"])
        self.topbar.pack(fill="x", padx=28, pady=(22,10))
        self.page_title = tk.Label(self.topbar, text="Dashboard", bg=C["bg"], fg=C["text"], font=("DejaVu Sans", 22, "bold"))
        self.page_title.pack(side="left")
        self.top_hint = tk.Label(self.topbar, text="YOUR GAME SPACE", bg=C["bg"], fg=C["muted"], font=("DejaVu Sans", 8, "bold"))
        self.top_hint.pack(side="right", pady=10)
        self.content = tk.Frame(self.main, bg=C["bg"])
        self.content.pack(fill="both", expand=True, padx=28, pady=(6,10))
        self.footer = tk.Frame(self.main, bg=C["bg"])
        self.footer.pack(fill="x", padx=28, pady=(0,16))
        tk.Label(self.footer, text="NOVA PRO  •  Built for Bazzite", bg=C["bg"], fg=C["muted"], font=("DejaVu Sans", 8)).pack(side="left")
        self.footer_msg = tk.Label(self.footer, text="Ready", bg=C["bg"], fg=C["muted"], font=("DejaVu Sans", 8))
        self.footer_msg.pack(side="right")

    def clear_content(self):
        for w in self.content.winfo_children(): w.destroy()

    def show_page(self, page):
        self.page = page
        self.page_title.config(text=page)
        for n,b in self.nav_buttons.items():
            b.config(bg=C["panel2"] if n == page else C["sidebar"], fg=C["text"] if n == page else C["muted"])
        self.clear_content()
        getattr(self, "page_"+page.lower())()

    def page_dashboard(self):
        hero = tk.Frame(self.content, bg=C["panel2"], highlightbackground=C["line"], highlightthickness=1)
        hero.pack(fill="x", pady=(0,14))
        left = tk.Frame(hero, bg=C["panel2"])
        left.pack(side="left", fill="both", expand=True, padx=22, pady=22)
        tk.Label(left, text="YOUR NEXT SESSION STARTS HERE", bg=C["panel2"], fg=C["cyan"], font=("DejaVu Sans", 8, "bold")).pack(anchor="w")
        tk.Label(left, text="Drop in. Lock in.", bg=C["panel2"], fg=C["text"], font=("DejaVu Sans", 25, "bold")).pack(anchor="w", pady=(7,3))
        tk.Label(left, text="A clean control center for Roblox on Linux.", bg=C["panel2"], fg=C["muted"], font=("DejaVu Sans", 10)).pack(anchor="w", pady=(0,15))
        row = tk.Frame(left, bg=C["panel2"]); row.pack(anchor="w")
        self.button(row, "▶  LAUNCH ROBLOX", self.launch, True).pack(side="left", padx=(0,8))
        self.button(row, "OPEN ROBLOX.COM", lambda:webbrowser.open("https://www.roblox.com/"), False).pack(side="left")
        tk.Label(hero, text="N\nO\nV\nA", bg=C["panel2"], fg=C["purple"], font=("DejaVu Sans", 18, "bold"), justify="center").pack(side="right", padx=28, pady=18)

        stats = tk.Frame(self.content, bg=C["bg"]); stats.pack(fill="x", pady=(0,14))
        self.stat_labels = {}
        for key, title, value in [("sober","PLAYER","Checking…"),("cpu","SYSTEM LOAD","—"),("ram","MEMORY","—")]:
            c = self.card(stats)
            c.pack(side="left", fill="both", expand=True, padx=(0,10))
            tk.Label(c, text=title, bg=C["panel"], fg=C["muted"], font=("DejaVu Sans",8,"bold")).pack(anchor="w", padx=14, pady=(13,5))
            val = tk.Label(c, text=value, bg=C["panel"], fg=C["text"], font=("DejaVu Sans", 14, "bold"))
            val.pack(anchor="w", padx=14, pady=(0,13))
            self.stat_labels[key] = val

        bottom = tk.Frame(self.content, bg=C["bg"]); bottom.pack(fill="both", expand=True)
        quick = self.card(bottom, "Quick actions", "Handy shortcuts")
        quick.pack(side="left", fill="both", expand=True, padx=(0,10))
        for label, action in [
            ("⚙  Tune settings", lambda:self.show_page("Settings")),
            ("◈  Performance center", lambda:self.show_page("Performance")),
            ("▦  Manage profiles", lambda:self.show_page("Profiles")),
            ("↗  Official Sober docs", lambda:webbrowser.open("https://vinegarhq.org/Sober/Configuration/index.html"))]:
            self.button(quick, label, action).pack(fill="x", padx=14, pady=4)
        news = self.card(bottom, "Before you launch", "Small but important")
        news.pack(side="left", fill="both", expand=True)
        tk.Label(news, text="• Settings apply to Sober, not Roblox itself.\n\n• Restart Sober after changing config.\n\n• No FPS number is fabricated; system stats are best-effort.", bg=C["panel"], fg=C["muted"], justify="left", font=("DejaVu Sans", 9)).pack(anchor="w", padx=15, pady=10)

    def page_settings(self):
        top = self.card(self.content, "Player settings", "Edits are saved locally and applied to Sober's config.")
        top.pack(fill="x", pady=(0,12))
        r = tk.Frame(top, bg=C["panel"]); r.pack(fill="x", padx=16, pady=(4,10))
        tk.Label(r, text="Graphics preset", bg=C["panel"], fg=C["text"], font=("DejaVu Sans",10,"bold")).pack(side="left")
        self.graphics = tk.StringVar(value=self.settings.get("graphics_optimization_mode","balanced"))
        ttk.Combobox(r, textvariable=self.graphics, values=["performance","balanced","quality"], state="readonly", width=18, style="Nova.TCombobox").pack(side="right")
        opts = [
            ("enable_gamemode","Enable GameMode integration","May improve scheduling on supported systems."),
            ("use_opengl","Use OpenGL instead of Vulkan","Compatibility troubleshooting option; may reduce performance."),
            ("enable_hidpi","High-DPI scaling","Useful on high-resolution displays."),
            ("discord_rpc_enabled","Discord Rich Presence","Show supported activity status."),
            ("discord_rpc_show_join_button","Discord join button","Only applies when Rich Presence is enabled."),
            ("server_location_indicator_enabled","Server location indicator","Show location info when available."),
            ("enable_mobile_home_screen","Mobile-style home screen","Use the mobile-style interface."),
            ("allow_gamepad_permission","Gamepad / controller support","Allow controller support where supported."),
            ("close_on_leave","Close game process on leave","Sober behavior option."),
        ]
        grid = tk.Frame(self.content, bg=C["bg"]); grid.pack(fill="both", expand=True)
        self.vars = {}
        for i,(key,label,desc) in enumerate(opts):
            c = self.card(grid)
            c.grid(row=i//2, column=i%2, sticky="nsew", padx=(0,10 if i%2==0 else 0), pady=(0,10))
            v = tk.BooleanVar(value=bool(self.settings.get(key, DEFAULTS.get(key,False))))
            self.vars[key] = v
            tk.Checkbutton(c, text=label, variable=v, bg=C["panel"], fg=C["text"], activebackground=C["panel"], activeforeground=C["text"], selectcolor=C["panel2"], font=("DejaVu Sans",9,"bold"), anchor="w", wraplength=300).pack(fill="x", padx=14, pady=(12,3))
            tk.Label(c, text=desc, bg=C["panel"], fg=C["muted"], font=("DejaVu Sans",8), wraplength=300, justify="left").pack(anchor="w", padx=15, pady=(0,12))
        grid.grid_columnconfigure(0, weight=1); grid.grid_columnconfigure(1, weight=1)
        actions = tk.Frame(self.content, bg=C["bg"]); actions.pack(fill="x", pady=(6,0))
        self.button(actions, "SAVE + APPLY", self.save_settings, True).pack(side="left")
        self.button(actions, "RESTORE DEFAULTS", self.reset_settings).pack(side="left", padx=8)
        self.button(actions, "OPEN CONFIG FOLDER", self.open_config).pack(side="right")

    def page_performance(self):
        intro = self.card(self.content, "Performance center", "Real system readings where available — no fake FPS meter.")
        intro.pack(fill="x", pady=(0,12))
        self.perf_labels = {}
        for key,title,desc in [
            ("cpu","System load","Linux load average; not a direct CPU percentage."),
            ("ram","Memory use","Used / total RAM based on /proc/meminfo."),
            ("gpu","Graphics driver","Detected DRM driver name, when exposed by the system."),
        ]:
            c = self.card(self.content, title, desc); c.pack(fill="x", pady=5)
            val = tk.Label(c, text="Reading…", bg=C["panel"], fg=C["cyan"], font=("DejaVu Sans",14,"bold"))
            val.pack(anchor="w", padx=16, pady=(0,13)); self.perf_labels[key] = val
        row = tk.Frame(self.content, bg=C["bg"]); row.pack(fill="x", pady=10)
        self.button(row, "↻  REFRESH STATS", self.refresh_stats, True).pack(side="left")
        self.button(row, "OPEN BAZZITE GAMING GUIDE", lambda:webbrowser.open("https://docs.bazzite.gg/"), False).pack(side="left", padx=8)
        tk.Label(self.content, text="Tip: close heavy background apps, keep the GPU driver current, and test one setting at a time. Avoid random 'FPS boost' scripts.", bg=C["bg"], fg=C["muted"], wraplength=760, justify="left", font=("DejaVu Sans",9)).pack(anchor="w", pady=12)

    def page_profiles(self):
        intro = self.card(self.content, "Profiles", "One-click setting presets. They change launcher-managed options only.")
        intro.pack(fill="x", pady=(0,14))
        presets = [
            ("Performance","Lower overhead / compatibility-first defaults", {"graphics_optimization_mode":"performance","enable_gamemode":True,"use_opengl":False,"enable_hidpi":False}),
            ("Balanced","Recommended starting point", {"graphics_optimization_mode":"balanced","enable_gamemode":True,"use_opengl":False,"enable_hidpi":False}),
            ("Quality","Keep display scaling enabled if you need it", {"graphics_optimization_mode":"quality","enable_gamemode":True,"use_opengl":False,"enable_hidpi":True}),
            ("Compatibility","Try OpenGL only if Vulkan causes issues", {"graphics_optimization_mode":"balanced","enable_gamemode":False,"use_opengl":True,"enable_hidpi":False}),
        ]
        for name,desc,values in presets:
            c = self.card(self.content, name, desc); c.pack(fill="x", pady=5)
            self.button(c, "APPLY PROFILE", lambda n=name,v=values:self.apply_profile(n,v), True, True).pack(anchor="e", padx=14, pady=(0,12))
        tk.Label(self.content, text="Presets are suggestions, not guaranteed FPS improvements. You can fine-tune each option under Settings.", bg=C["bg"], fg=C["muted"], font=("DejaVu Sans",9)).pack(anchor="w", pady=10)

    def page_tools(self):
        c = self.card(self.content, "Tools & shortcuts", "Safe maintenance actions for your local setup.")
        c.pack(fill="x", pady=(0,12))
        items = [
            ("Check Sober installation", self.refresh_status),
            ("Open Sober configuration folder", self.open_config),
            ("Open official Sober installation guide", lambda:webbrowser.open("https://vinegarhq.org/Sober/Installation.html")),
            ("Open official Sober settings reference", lambda:webbrowser.open("https://vinegarhq.org/Sober/Configuration/index.html")),
            ("Open Roblox website", lambda:webbrowser.open("https://www.roblox.com/")),
            ("View launcher log", self.view_log),
            ("Export NOVA settings", self.export_settings),
            ("Import NOVA settings", self.import_settings),
        ]
        for label,fn in items:
            self.button(c, label, fn).pack(fill="x", padx=15, pady=4)
        tk.Label(self.content, text="NOVA will never ask for your Roblox password or collect browser cookies.", bg=C["bg"], fg=C["green"], font=("DejaVu Sans",9,"bold")).pack(anchor="w", pady=12)

    def page_about(self):
        c = self.card(self.content, "NOVA Pro", "A community-style launcher interface for Bazzite Linux.")
        c.pack(fill="x", pady=(0,12))
        tk.Label(c, text="Built for people who want one tidy place to launch Sober and manage common settings.\n\nThis is an independent utility and is not affiliated with Roblox Corporation or VinegarHQ.\n\nSober is a third-party Linux Roblox player. Availability and compatibility can change; follow its official documentation.", bg=C["panel"], fg=C["text"], justify="left", wraplength=740, font=("DejaVu Sans",10)).pack(anchor="w", padx=16, pady=15)
        self.button(c, "OPEN OFFICIAL SOBER DOCS", lambda:webbrowser.open("https://vinegarhq.org/Sober/"), True).pack(anchor="w", padx=16, pady=(0,15))
        c2 = self.card(self.content, "Paths")
        c2.pack(fill="x")
        tk.Label(c2, text=f"NOVA data: {ROOT}\nSober config: {SOBER_CONFIG}\nLauncher log: {LOG}", bg=C["panel"], fg=C["muted"], justify="left", font=("DejaVu Sans Mono",9)).pack(anchor="w", padx=16, pady=14)

    def refresh_status(self):
        installed = has_flatpak()
        text = "● SOBER READY" if installed else "● SOBER NOT FOUND"
        color = C["green"] if installed else C["yellow"]
        self.sidebar_status.config(text=text, fg=color)
        if hasattr(self, "stat_labels") and "sober" in self.stat_labels:
            self.stat_labels["sober"].config(text="Installed" if installed else "Not installed", fg=color)
        self.footer_msg.config(text="Sober ready" if installed else "Sober not detected")
        write_log("Sober check: " + ("installed" if installed else "not detected"))

    def launch(self):
        if not has_flatpak():
            if messagebox.askyesno("Sober not installed", "Sober was not detected. Open the official installation guide?"):
                webbrowser.open("https://vinegarhq.org/Sober/Installation.html")
            return
        args = ["flatpak", "run", SOBER_ID]
        extra = self.settings.get("launch_arguments","").strip()
        if extra:
            # Split into args without shell evaluation.
            import shlex
            args += shlex.split(extra)
        try:
            subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            self.footer_msg.config(text="Launch requested")
            write_log("Launch requested: " + repr(args))
        except Exception as e:
            messagebox.showerror("Launch failed", str(e))

    def save_settings(self):
        self.settings["graphics_optimization_mode"] = self.graphics.get()
        for k,v in self.vars.items(): self.settings[k] = bool(v.get())
        self.settings["profile"] = "Custom"
        DATA.write_text(json.dumps(self.settings, indent=2)+"\n", encoding="utf-8")
        try:
            changes = {k:self.settings[k] for k in [
                "graphics_optimization_mode","enable_gamemode","use_opengl","enable_hidpi",
                "discord_rpc_enabled","discord_rpc_show_join_button","server_location_indicator_enabled",
                "enable_mobile_home_screen","allow_gamepad_permission","close_on_leave"]}
            save_sober_config(changes)
            self.footer_msg.config(text="Settings saved")
            write_log("Settings saved and applied to Sober config.")
            messagebox.showinfo("Settings saved", f"Saved locally and applied to Sober.\n\nBackup (if config existed):\n{SOBER_CONFIG.with_name('config.json.nova-backup')}\n\nRestart Sober for changes to take effect.")
        except Exception as e:
            messagebox.showerror("Save failed", f"NOVA settings were saved, but Sober config could not be updated:\n{e}")

    def reset_settings(self):
        if not messagebox.askyesno("Restore defaults", "Reset the visible player settings to the recommended defaults?"):
            return
        self.settings.update(DEFAULTS)
        self.show_page("Settings")
        self.footer_msg.config(text="Defaults loaded — press Save + Apply")

    def apply_profile(self, name, values):
        self.settings.update(values); self.settings["profile"] = name
        DATA.write_text(json.dumps(self.settings, indent=2)+"\n", encoding="utf-8")
        try:
            save_sober_config(values)
            self.footer_msg.config(text=f"{name} profile applied")
            write_log("Profile applied: "+name)
            messagebox.showinfo("Profile applied", f"{name} profile applied.\nRestart Sober for changes to take effect.")
        except Exception as e:
            messagebox.showerror("Could not apply profile", str(e))

    def open_config(self):
        SOBER_CONFIG.parent.mkdir(parents=True, exist_ok=True)
        subprocess.Popen(["xdg-open", str(SOBER_CONFIG.parent)])
    def view_log(self):
        LOG.touch(exist_ok=True)
        subprocess.Popen(["xdg-open", str(LOG)])
    def export_settings(self):
        path = filedialog.asksaveasfilename(title="Export NOVA settings", defaultextension=".json", filetypes=[("JSON files","*.json")], initialfile="nova-settings.json")
        if path:
            shutil.copy2(DATA, path) if DATA.exists() else Path(path).write_text(json.dumps(self.settings,indent=2))
            self.footer_msg.config(text="Settings exported")
    def import_settings(self):
        path = filedialog.askopenfilename(title="Import NOVA settings", filetypes=[("JSON files","*.json")])
        if not path: return
        try:
            imported = json.loads(Path(path).read_text(encoding="utf-8"))
            if not isinstance(imported,dict): raise ValueError("Settings file must contain a JSON object.")
            self.settings.update({k:v for k,v in imported.items() if k in DEFAULTS})
            DATA.write_text(json.dumps(self.settings,indent=2)+"\n", encoding="utf-8")
            self.footer_msg.config(text="Settings imported")
            messagebox.showinfo("Imported", "Settings imported. Open Settings and press Save + Apply to update Sober.")
        except Exception as e: messagebox.showerror("Import failed", str(e))

    def refresh_stats(self):
        cpu,ram,gpu = sys_stats()
        if hasattr(self,"stat_labels"):
            if "cpu" in self.stat_labels: self.stat_labels["cpu"].config(text=cpu)
            if "ram" in self.stat_labels: self.stat_labels["ram"].config(text=ram)
        if hasattr(self,"perf_labels"):
            for k,v in [("cpu",cpu),("ram",ram),("gpu",gpu)]:
                if k in self.perf_labels: self.perf_labels[k].config(text=v)
        self.root.after(8000, self.refresh_stats)

if __name__ == "__main__":
    root = tk.Tk()
    app = Nova(root)
    root.mainloop()
