#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/share/nova-pro"
BIN="$HOME/.local/bin/nova-pro"
APPS="$HOME/.local/share/applications"
mkdir -p "$DEST" "$BIN" "$APPS"
cp "$HERE/nova/nova_pro.py" "$DEST/nova_pro.py"
cat > "$BIN" <<'EOF'
#!/usr/bin/env bash
exec python3 "$HOME/.local/share/nova-pro/nova_pro.py" "$@"
EOF
chmod +x "$BIN" "$DEST/nova_pro.py"
cat > "$APPS/nova-pro.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=NOVA Pro
Comment=Roblox and Sober control center for Bazzite
Exec=$BIN
Terminal=false
Categories=Game;Utility;
StartupNotify=true
EOF
chmod +x "$APPS/nova-pro.desktop"
echo
echo "NOVA Pro installed!"
echo "Launch it from your app menu, or run: $BIN"
echo "If Python Tkinter is unavailable, install it using your preferred Bazzite-compatible method."
read -r -p "Press Enter to close..."
