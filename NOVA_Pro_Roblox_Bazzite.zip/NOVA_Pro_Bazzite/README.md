# NOVA Pro — Bazzite Roblox/Sober launcher

A more complete desktop control center for launching Sober and managing common Sober settings. It installs to your home directory, which is appropriate for immutable Bazzite systems.

## Included
- Multi-page UI: Dashboard, Settings, Performance, Profiles, Tools, About
- Launch Sober via Flatpak
- Sober configuration toggles and graphics preset
- Four one-click profiles
- Live best-effort Linux load, RAM and GPU driver readings (not an FPS counter)
- Import/export NOVA settings, launcher log, open config folder
- Backup of Sober config before changes
- No password collection or browser-cookie handling

## Install
1. Extract the ZIP.
2. Open a terminal in the extracted `NOVA_Pro_Bazzite` folder.
3. Run:
   ```bash
   chmod +x install.sh
   ./install.sh
   ```
4. Open **NOVA Pro** from the applications menu.

## Requirements
- Bazzite/Linux desktop session
- Python 3 and Tkinter
- Flatpak for launching/installing Sober

## Notes
- If Sober is missing, use the official install guide: https://vinegarhq.org/Sober/Installation.html
- Settings apply to Sober and may require restarting it.
- The graphics preset is a configuration preference, not a guaranteed FPS boost.
- System load is not a direct CPU percentage and this app does not claim to measure in-game FPS.
- NOVA is independent and is not affiliated with Roblox Corporation or VinegarHQ.
